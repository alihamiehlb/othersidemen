"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Globe, Diamond, RotateCcw, Shield, Headphones } from "lucide-react"

const benefits = [
  {
    icon: Globe,
    title: "WORLDWIDE SHIPPING",
    description: "We deliver globally. No limits.",
  },
  {
    icon: Diamond,
    title: "PREMIUM QUALITY",
    description: "Built to last. Always.",
  },
  {
    icon: RotateCcw,
    title: "EASY RETURNS",
    description: "Not your fit? We've got you.",
  },
  {
    icon: Shield,
    title: "SECURE PAYMENT",
    description: "100% safe & encrypted.",
  },
  {
    icon: Headphones,
    title: "STYLE SUPPORT",
    description: "We're here for you. Anytime.",
  },
]

export function BrandBenefits() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-50px" })

  return (
    <section ref={ref} className="py-16 bg-card border-t border-b border-border">
      <div className="max-w-[1400px] mx-auto px-4 md:px-6">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
          {benefits.map((benefit, index) => (
            <motion.div
              key={benefit.title}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex flex-col items-center text-center"
            >
              <div className="w-12 h-12 rounded-full border border-border flex items-center justify-center mb-4">
                <benefit.icon className="w-5 h-5 text-muted-foreground" />
              </div>
              <h3 className="text-xs font-medium tracking-widest mb-1">{benefit.title}</h3>
              <p className="text-xs text-muted-foreground">{benefit.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
