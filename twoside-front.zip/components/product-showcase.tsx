"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Heart, ArrowRight } from "lucide-react"

const products = [
  {
    id: 1,
    name: "UTILITY PUFFER JACKET",
    price: 129.00,
    image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=500&auto=format&fit=crop",
  },
  {
    id: 2,
    name: "OVERSIZED DENIM JACKET",
    price: 89.00,
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=500&auto=format&fit=crop",
  },
  {
    id: 3,
    name: "CARGO DENIM PANTS",
    price: 79.00,
    image: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?q=80&w=500&auto=format&fit=crop",
  },
  {
    id: 4,
    name: "MINIMAL ZIP HOODIE",
    price: 69.00,
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=500&auto=format&fit=crop",
  },
  {
    id: 5,
    name: "WIDE LEG TROUSERS",
    price: 74.00,
    image: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?q=80&w=500&auto=format&fit=crop",
  },
  {
    id: 6,
    name: "ESSENTIAL SNEAKERS",
    price: 99.00,
    image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?q=80&w=500&auto=format&fit=crop",
  },
]

export function ProductShowcase() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section ref={ref} className="py-20 md:py-32 bg-background">
      <div className="max-w-[1400px] mx-auto px-4 md:px-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <span className="text-xs tracking-[0.3em] text-muted-foreground">NEW IN</span>
          </motion.div>
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="flex items-center gap-2 text-sm tracking-widest text-foreground hover:text-muted-foreground transition-colors group"
          >
            SHOP ALL
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </motion.button>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.08 }}
              className="group cursor-pointer"
            >
              <div className="relative aspect-[3/4] bg-card rounded-xl overflow-hidden mb-3">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <button className="absolute top-3 right-3 w-8 h-8 bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                  <Heart className="w-4 h-4" />
                </button>
              </div>
              <h3 className="text-[10px] md:text-xs font-medium tracking-wide mb-1 truncate">{product.name}</h3>
              <p className="text-xs text-muted-foreground">${product.price.toFixed(2)}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
