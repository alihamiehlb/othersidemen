"use client"

import { useState, useRef } from "react"
import { motion, useInView } from "framer-motion"
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react"

// Custom icons matching the template
const ShirtIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="1.5">
    <path d="M6 2l3 3h6l3-3M6 2v6M18 2v6M6 8h12M6 8l-2 14h16l-2-14" />
  </svg>
)

const PantsIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="1.5">
    <path d="M6 2h12v6l-2 14h-3l-1-14-1 14h-3L6 8V2z" />
  </svg>
)

const JacketIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="1.5">
    <path d="M8 2h8l2 4v16H6V6l2-4zM8 2v4M16 2v4M6 10h12" />
  </svg>
)

const ShoeIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="1.5">
    <path d="M4 16h16v2H4zM6 16V10c0-2 2-4 6-4s6 2 6 4v6" />
  </svg>
)

const WatchIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="1.5">
    <circle cx="12" cy="12" r="6" />
    <path d="M12 6V2M12 22v-4M12 9v3l2 2" />
  </svg>
)

const categories = [
  { id: "tops", label: "TOPS", icon: ShirtIcon },
  { id: "bottoms", label: "BOTTOMS", icon: PantsIcon },
  { id: "outerwear", label: "OUTERWEAR", icon: JacketIcon },
  { id: "footwear", label: "FOOTWEAR", icon: ShoeIcon },
  { id: "accessories", label: "ACCESSORIES", icon: WatchIcon },
]

// Clothing items grid - matching the template layout
const clothingItems = [
  // Row 1 - Tops (t-shirts)
  { id: 1, image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=400", category: "tops" },
  { id: 2, image: "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?q=80&w=400", category: "tops" },
  { id: 3, image: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?q=80&w=400", category: "tops" },
  // Row 2 - Jackets/Outerwear
  { id: 4, image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=400", category: "outerwear" },
  { id: 5, image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=400", category: "outerwear" },
  { id: 6, image: "https://images.unsplash.com/photo-1544022613-e87ca75a784a?q=80&w=400", category: "outerwear" },
  // Row 3 - Bottoms/Footwear
  { id: 7, image: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?q=80&w=400", category: "bottoms" },
  { id: 8, image: "https://images.unsplash.com/photo-1542272604-787c3835535d?q=80&w=400", category: "bottoms" },
  { id: 9, image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?q=80&w=400", category: "footwear" },
]

const viewOptions = ["FRONT", "SIDE", "BACK"]

export function OutfitBuilder() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })
  const [activeCategory, setActiveCategory] = useState("tops")
  const [activeView, setActiveView] = useState("FRONT")
  const [selectedItems, setSelectedItems] = useState<number[]>([])

  const toggleItem = (id: number) => {
    setSelectedItems(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  return (
    <section ref={ref} id="outfit-builder" className="py-20 md:py-32 bg-background">
      <div className="max-w-[1400px] mx-auto px-4 md:px-6">
        <div className="grid lg:grid-cols-[220px_1fr_320px] gap-6 lg:gap-8">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <span className="text-xs tracking-[0.3em] text-muted-foreground">OUTFIT BUILDER</span>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight leading-tight">
              Build it.
              <br />
              Wear it.
              <br />
              Own it.
            </h2>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Mix. Match. Make it yours.
              <br />
              See every piece come
              <br />
              together in real time.
            </p>
            <button className="flex items-center gap-2 text-sm tracking-widest text-foreground hover:text-muted-foreground transition-colors group">
              START BUILDING
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            {/* Categories */}
            <div className="space-y-1 pt-4">
              {categories.map((cat) => {
                const IconComponent = cat.icon
                return (
                  <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${
                      activeCategory === cat.id
                        ? "bg-secondary text-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <IconComponent />
                    <span className="text-xs tracking-widest">{cat.label}</span>
                  </button>
                )
              })}
            </div>
          </motion.div>

          {/* Center - Model Preview */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="relative aspect-[3/4] bg-card rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1617137968427-85924c800a22?q=80&w=800&auto=format&fit=crop"
                alt="Model wearing denim jacket and cargo pants"
                className="w-full h-full object-cover"
              />
              {/* Navigation Arrows */}
              <button className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center text-foreground hover:bg-background transition-colors">
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center text-foreground hover:bg-background transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </motion.div>

          {/* Right - Item Selection Grid */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="space-y-4"
          >
            {/* 3x3 Grid of clothing items */}
            <div className="grid grid-cols-3 gap-2">
              {clothingItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => toggleItem(item.id)}
                  className={`aspect-square rounded-xl overflow-hidden border-2 transition-all ${
                    selectedItems.includes(item.id)
                      ? "border-foreground ring-2 ring-foreground/20"
                      : "border-border hover:border-muted-foreground"
                  }`}
                >
                  <img
                    src={item.image}
                    alt={`Clothing item ${item.id}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>

            {/* View Toggle */}
            <div className="flex gap-2">
              {viewOptions.map((view) => (
                <button
                  key={view}
                  onClick={() => setActiveView(view)}
                  className={`flex-1 py-3 rounded-xl text-xs tracking-widest transition-colors ${
                    activeView === view
                      ? "bg-foreground text-background"
                      : "bg-secondary text-foreground hover:bg-secondary/80"
                  }`}
                >
                  {view}
                </button>
              ))}
            </div>

            {/* Save Button */}
            <button className="w-full py-4 bg-secondary text-foreground rounded-xl text-sm tracking-widest hover:bg-secondary/80 transition-colors border border-border">
              SAVE OUTFIT
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
