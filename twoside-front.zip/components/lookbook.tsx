"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { ArrowRight, ChevronRight } from "lucide-react"

const lookbooks = [
  {
    id: "winter",
    title: "WINTER LAYERS",
    image: "https://images.unsplash.com/photo-1544441893-675973e31985?q=80&w=800&auto=format&fit=crop",
  },
  {
    id: "city",
    title: "CITY ESSENTIALS",
    image: "https://images.unsplash.com/photo-1490578474895-699cd4e2cf59?q=80&w=800&auto=format&fit=crop",
  },
  {
    id: "offduty",
    title: "OFF DUTY LOOKS",
    image: "https://images.unsplash.com/photo-1516826957135-700dedea698c?q=80&w=800&auto=format&fit=crop",
  },
  {
    id: "evening",
    title: "EVENING REFINED",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=800&auto=format&fit=crop",
  },
  {
    id: "weekend",
    title: "WEEKEND ESCAPE",
    image: "https://images.unsplash.com/photo-1488161628813-04466f872be2?q=80&w=800&auto=format&fit=crop",
  },
]

export function Lookbook() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section ref={ref} id="lookbook" className="py-20 md:py-32 bg-card">
      <div className="max-w-[1400px] mx-auto px-4 md:px-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-start gap-8 mb-12">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="space-y-4 lg:w-[200px] flex-shrink-0"
          >
            <span className="text-xs tracking-[0.3em] text-muted-foreground">LOOKBOOK</span>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight leading-tight">
              Real fits.
              <br />
              Real people.
              <br />
              Real life.
            </h2>
            <button className="flex items-center gap-2 text-sm tracking-widest text-foreground hover:text-muted-foreground transition-colors group pt-4">
              VIEW ALL LOOKS
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </motion.div>

          {/* Lookbook Cards */}
          <div className="relative flex-1">
            <div className="flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory scrollbar-hide">
              {lookbooks.map((look, index) => (
                <motion.div
                  key={look.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="flex-shrink-0 w-[180px] md:w-[200px] snap-start"
                >
                  <div className="group cursor-pointer">
                    <div className="relative aspect-[3/4] overflow-hidden rounded-xl">
                      <img
                        src={look.image}
                        alt={look.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
                      <div className="absolute bottom-4 left-4 right-4">
                        <h3 className="text-sm font-bold tracking-wide leading-tight">{look.title}</h3>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Navigation Arrow */}
            <button className="absolute -right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-foreground text-background rounded-full flex items-center justify-center hover:bg-foreground/90 transition-colors hidden lg:flex z-10">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
