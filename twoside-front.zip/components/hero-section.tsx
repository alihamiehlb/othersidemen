"use client"

import { motion } from "framer-motion"
import { ArrowDown } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Split Background - Left Side with Model */}
      <div className="absolute inset-0">
        {/* Left dark background with model */}
        <div className="absolute left-0 top-0 w-1/2 h-full">
          <img
            src="https://images.unsplash.com/photo-1617137968427-85924c800a22?q=80&w=1974&auto=format&fit=crop"
            alt="Model in dark clothing"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/60 via-background/80 to-background" />
        </div>
        {/* Right side with concrete/light model */}
        <div className="absolute right-0 top-0 w-1/2 h-full hidden lg:block">
          <img
            src="https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?q=80&w=1974&auto=format&fit=crop"
            alt="Model in cream jacket"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-transparent via-transparent to-background/90" />
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-[1400px] mx-auto px-4 md:px-6 w-full">
        <div className="grid lg:grid-cols-2 gap-8 items-center min-h-screen pt-20">
          {/* Left Content */}
          <div className="space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <span className="text-xs tracking-[0.3em] text-muted-foreground">OTHERSIDE DNA</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight leading-[0.9] text-balance"
            >
              TWO SIDES.
              <br />
              ONE IDENTITY.
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="text-muted-foreground text-lg max-w-md"
            >
              Tailored for modern living.
              <br />
              Designed to make every side yours.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="flex flex-wrap gap-4"
            >
              <button className="px-8 py-4 bg-foreground text-background text-sm tracking-widest hover:bg-foreground/90 transition-colors rounded-lg">
                EXPLORE MEN
              </button>
              <button className="px-8 py-4 border border-foreground text-foreground text-sm tracking-widest hover:bg-foreground hover:text-background transition-colors rounded-lg">
                EXPLORE WOMEN
              </button>
            </motion.div>
          </div>

          {/* Right - Floating Logo Badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.4 }}
            className="relative hidden lg:flex items-center justify-center"
          >
            {/* Floating Logo Badge */}
            <div className="absolute top-1/3 left-1/4 bg-card/90 backdrop-blur-sm rounded-2xl w-24 h-24 flex items-center justify-center border border-border shadow-2xl">
              <div className="text-center text-xs font-bold leading-tight">
                <span className="block border-b border-foreground pb-1 mb-1">OTHER</span>
                <span className="block">SIDE</span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute bottom-8 left-4 md:left-6 flex items-center gap-2 text-muted-foreground"
        >
          <span className="text-xs tracking-widest">SCROLL TO DISCOVER</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
          >
            <ArrowDown className="w-4 h-4" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
