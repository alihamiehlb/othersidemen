"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { Search, User, Heart, ShoppingBag, Menu, X } from "lucide-react"

const navLinks = [
  { label: "NEW IN", href: "#" },
  { label: "CLOTHING", href: "#" },
  { label: "SHOES", href: "#" },
  { label: "ACCESSORIES", href: "#" },
  { label: "OUTFIT BUILDER", href: "#outfit-builder" },
  { label: "LOOKBOOK", href: "#lookbook" },
  { label: "SALE", href: "#" },
]

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <>
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? "bg-background/80 backdrop-blur-xl border-b border-border" : "bg-transparent"
        }`}
      >
        <div className="max-w-[1400px] mx-auto px-4 md:px-6">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <Link href="/" className="flex-shrink-0">
              <div className="text-foreground font-bold text-lg tracking-tight leading-none">
                <div className="border border-foreground px-2 py-1">
                  <span className="block text-xs tracking-[0.2em]">OTHER</span>
                  <span className="block text-xs tracking-[0.2em]">SIDE</span>
                </div>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.label}
                  href={link.href}
                  className="text-xs tracking-widest text-muted-foreground hover:text-foreground transition-colors duration-200"
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            {/* Right Icons */}
            <div className="flex items-center gap-4">
              <button className="p-2 text-muted-foreground hover:text-foreground transition-colors">
                <Search className="w-5 h-5" />
              </button>
              <button className="hidden sm:block p-2 text-muted-foreground hover:text-foreground transition-colors">
                <User className="w-5 h-5" />
              </button>
              <button className="hidden sm:block p-2 text-muted-foreground hover:text-foreground transition-colors">
                <Heart className="w-5 h-5" />
              </button>
              <button className="p-2 text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1">
                <ShoppingBag className="w-5 h-5" />
                <span className="text-xs">(0)</span>
              </button>
              <button
                className="lg:hidden p-2 text-muted-foreground hover:text-foreground transition-colors"
                onClick={() => setIsMobileMenuOpen(true)}
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-background"
          >
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between p-4 border-b border-border">
                <div className="text-foreground font-bold text-lg tracking-tight leading-none">
                  <div className="border border-foreground px-2 py-1">
                    <span className="block text-xs tracking-[0.2em]">OTHER</span>
                    <span className="block text-xs tracking-[0.2em]">SIDE</span>
                  </div>
                </div>
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              <nav className="flex-1 flex flex-col justify-center p-8">
                {navLinks.map((link, index) => (
                  <motion.div
                    key={link.label}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Link
                      href={link.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className="block py-4 text-2xl font-light tracking-wide text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {link.label}
                    </Link>
                  </motion.div>
                ))}
              </nav>
              <div className="p-8 border-t border-border flex gap-6">
                <button className="p-2 text-muted-foreground hover:text-foreground transition-colors">
                  <User className="w-6 h-6" />
                </button>
                <button className="p-2 text-muted-foreground hover:text-foreground transition-colors">
                  <Heart className="w-6 h-6" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
