"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { ArrowRight } from "lucide-react"

const styleCards = [
  {
    id: "minimal",
    title: "MINIMAL",
    description: "Clean. Simple. Timeless.",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "street",
    title: "STREET",
    description: "Bold. Urban. Effortless.",
    image: "https://images.unsplash.com/photo-1534308143481-c55f00be8bd7?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "creative",
    title: "CREATIVE",
    description: "Unique. Expressive. You.",
    image: "https://images.unsplash.com/photo-1492288991661-058aa541ff43?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "classic",
    title: "CLASSIC",
    description: "Sharp. Refined. Always.",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "tech",
    title: "TECH",
    description: "Functional. Modern. Futuristic.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=600&auto=format&fit=crop",
  },
]

export function StyleDNA() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section ref={ref} className="py-20 md:py-32 bg-card">
      <div className="max-w-[1400px] mx-auto px-4 md:px-6">
        <div className="grid lg:grid-cols-[280px_1fr] gap-8 lg:gap-12">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <span className="text-xs tracking-[0.3em] text-muted-foreground">STYLE DNA</span>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
              What&apos;s
              <br />
              your vibe?
            </h2>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Your style, your personality.
              <br />
              We help you find the looks
              <br />
              that match your DNA.
            </p>
            <button className="flex items-center gap-2 text-sm tracking-widest text-foreground hover:text-muted-foreground transition-colors group">
              TAKE THE QUIZ
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </motion.div>

          {/* Style Cards */}
          <div className="flex gap-4 overflow-x-auto pb-4 lg:pb-0 snap-x snap-mandatory scrollbar-hide">
            {styleCards.map((card, index) => (
              <motion.div
                key={card.id}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="flex-shrink-0 w-[160px] lg:w-[140px] xl:w-[160px] snap-start"
              >
                <div className="group cursor-pointer">
                  <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-secondary mb-4">
                    <img
                      src={card.image}
                      alt={card.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </div>
                  <h3 className="font-bold text-sm tracking-wide mb-1">{card.title}</h3>
                  <p className="text-xs text-muted-foreground">{card.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
