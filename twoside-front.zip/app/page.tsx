import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { StyleDNA } from "@/components/style-dna"
import { OutfitBuilder } from "@/components/outfit-builder"
import { Lookbook } from "@/components/lookbook"
import { ProductShowcase } from "@/components/product-showcase"
import { BrandBenefits } from "@/components/brand-benefits"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <Navbar />
      <HeroSection />
      <StyleDNA />
      <OutfitBuilder />
      <Lookbook />
      <ProductShowcase />
      <BrandBenefits />
      <Footer />
    </main>
  )
}
